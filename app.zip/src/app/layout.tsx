import type { Metadata } from "next";
import { Rufina, Inter} from "next/font/google";
import "./globals.css";

const rufina = Rufina({ subsets: ["latin"] ,weight: ["400", "700"], variable:"--font-rufina"  });
const inter = Inter({ subsets: ["latin"] ,weight: ["400", "700"], variable: "--font-inter"  });

export const metadata: Metadata = {
  title: "COSTA VERDE BBQ & GRILL",
  description: "Portuguese & Brazilian Restaurant",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={rufina.className}>{children}</body>
    </html>
  );
}
